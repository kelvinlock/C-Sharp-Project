﻿using System;
using System.Drawing;
using System.IO;
using System.Net.Mail;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace GamesPlatform
{
    public class RecordForm : Form
    {
        public string filePath = Path.Combine(Application.StartupPath, "Assets", "Data", "UserInfo.txt");
        public string username;
        public RecordForm(string playerName)
        {
            Text = "對戰紀錄";
            ClientSize = new Size(400, 300);
            StartPosition = FormStartPosition.CenterScreen;

            var txt = new TextBox()
            {
                Multiline = true,
                ReadOnly = true,
                Dock = DockStyle.Fill,
                ScrollBars = ScrollBars.Vertical,
                Font = new Font(Font.FontFamily, 10)
            };
            Controls.Add(txt);

            var folder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Records");
            var file = Path.Combine(folder, $"{playerName}_records.txt");
            string recordContent;

            if (File.Exists(file))
            {
                recordContent = string.Join(Environment.NewLine, File.ReadAllLines(file));
                txt.Text = recordContent;

                // 呼叫寄信方法
                SendEmail(recordContent);
            }
            else
            {
                txt.Text = "目前尚無紀錄。";
            }
        }
        private void SendEmail(string content)
        {
            try
            {
                MailMessage mail = new MailMessage();
                mail.From = new MailAddress("kelvinlock0714@gmail.com");
                mail.To.Add(GetEmail(username));
                mail.Subject = "對戰紀錄";
                mail.Body = content;

                SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587);
                smtp.Credentials = new System.Net.NetworkCredential("kelvinlock0714@gmail.com", "jggxldhhevgoctcf");
                smtp.EnableSsl = true;

                smtp.Send(mail);
                MessageBox.Show("紀錄已透過 Email 發送！");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Email 發送失敗：{ex.Message}", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private string GetEmail(string username)
        {
            try
            {
                if (!File.Exists(filePath))
                    return null;

                var lines = File.ReadAllLines(filePath);
                foreach (string line in lines)
                {
                    var parts = line.Split(',');
                    if (parts.Length >= 3 && parts[0].Trim().ToLower() == username.Trim().ToLower())
                    {
                        if (!string.IsNullOrWhiteSpace(parts[2]))
                            return parts[2].Trim();
                    }
                }
                return null;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Email 發送失敗：{ex.Message}", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }
    }
}