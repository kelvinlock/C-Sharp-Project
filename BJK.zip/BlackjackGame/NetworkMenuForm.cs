using System;
using System.Drawing;
using System.Windows.Forms;

namespace Blackjack21Game
{
    public class NetworkMenuForm : Form
    {
        private Button btnVsComputer, btnHost, btnJoin;

        public NetworkMenuForm()
        {
            Text = "遊戲模式";
            ClientSize = new Size(300, 200);
            StartPosition = FormStartPosition.CenterScreen;

            btnVsComputer = new Button() { Text = "VS 電腦", Location = new Point(90, 20), Size = new Size(120, 40) };
            btnHost      = new Button() { Text = "開啟主機", Location = new Point(90, 70), Size = new Size(120, 40) };
            btnJoin      = new Button() { Text = "加入遊戲", Location = new Point(90, 120), Size = new Size(120, 40) };

            btnVsComputer.Click += (s, e) =>
            {
                Hide();
                var login = new LoginForm();
                if (login.ShowDialog() == DialogResult.OK)
                {
                    var game = new GameForm(login.PlayerName);
                    game.ShowDialog();
                }
                Show();
            };

            btnHost.Click += (s, e) =>
            {
                Hide();
                var login = new LoginForm();
                if (login.ShowDialog() == DialogResult.OK)
                {
                    var hostForm = new HostGameForm(login.PlayerName);
                    hostForm.ShowDialog();
                }
                Show();
            };

            btnJoin.Click += (s, e) =>
            {
                Hide();
                var login = new LoginForm();
                if (login.ShowDialog() == DialogResult.OK)
                {
                    var joinForm = new JoinGameForm(login.PlayerName);
                    joinForm.ShowDialog();
                }
                Show();
            };

            Controls.AddRange(new Control[] { btnVsComputer, btnHost, btnJoin });
        }
    }
}
