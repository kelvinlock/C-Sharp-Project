using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Collections.Generic;

namespace Blackjack21Game
{
    public class GameForm : Form
    {
        private string playerName;
        private Deck deck;
        private Player player;
        private Player computer;
        private int playerWins, computerWins;
        private List<string> roundRecords = new List<string>();

        private Label lblWins, lblScore;
        private FlowLayoutPanel panelPlayer, panelComputer;
        private Button btnHit, btnStand;

        public GameForm(string name)
        {
            playerName = name;
            DoubleBuffered = true;
            InitializeComponent();
            StartNewRound();
        }

        private void InitializeComponent()
        {
            Text = "21點 Blackjack Game";
            ClientSize = new Size(800, 600);
            Font = new Font("Segoe UI", 10);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(30, 30, 30);

            lblWins  = new Label() { Location = new Point(10, 10), AutoSize = true, ForeColor = Color.White };
            lblScore = new Label() { Location = new Point(690, 10), AutoSize = true, ForeColor = Color.White };

            panelComputer = new FlowLayoutPanel()
            {
                Location    = new Point(50, 50),
                Size        = new Size(700, 150),
                BackColor   = Color.FromArgb(50, 50, 50),
                BorderStyle = BorderStyle.FixedSingle,
                Padding     = new Padding(10)
            };

            panelPlayer = new FlowLayoutPanel()
            {
                Location    = new Point(50, 400),
                Size        = new Size(700, 150),
                AutoScroll  = true,
                BackColor   = Color.FromArgb(50, 50, 50),
                BorderStyle = BorderStyle.FixedSingle,
                Padding     = new Padding(10)
            };

            btnHit   = new Button() { Text = "加牌", Location = new Point(300, 300), Size = new Size(80, 40) };
            btnStand = new Button() { Text = "結算", Location = new Point(400, 300), Size = new Size(80, 40) };

            foreach (var b in new[] { btnHit, btnStand })
            {
                b.FlatStyle = FlatStyle.Flat;
                b.FlatAppearance.BorderSize = 0;
                b.ForeColor = Color.White;
                b.BackColor = b == btnHit ? Color.FromArgb(45, 150, 75) : Color.FromArgb(200, 60, 60);
            }

            btnHit.Click   += BtnHit_Click;
            btnStand.Click += BtnStand_Click;

            Controls.AddRange(new Control[] { lblWins, lblScore, panelComputer, panelPlayer, btnHit, btnStand });
        }

        private void StartNewRound()
        {
            if (deck == null)
                deck = new Deck();

            if (deck.CardsRemaining < 2)
            {
                GameOver();
                return;
            }

            player   = new Player();
            computer = new Player();

            player.AddCard(deck.DrawCard());
            computer.AddCard(deck.DrawCard());

            RefreshUI();
            btnHit.Enabled = btnStand.Enabled = true;
        }

        private void RefreshUI()
        {
            panelPlayer.Controls.Clear();
            foreach (var c in player.Hand)
            {
                var pb = new PictureBox()
                {
                    Image    = Image.FromFile(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", c.GetImageFileName())),
                    SizeMode = PictureBoxSizeMode.Zoom,
                    Size     = new Size(80, 120),
                    Margin   = new Padding(5)
                };
                panelPlayer.Controls.Add(pb);
            }

            panelComputer.Controls.Clear();
            for (int i = 0; i < computer.Hand.Count; i++)
            {
                var backPic = new PictureBox()
                {
                    Image    = Image.FromFile(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", "back.png")),
                    SizeMode = PictureBoxSizeMode.Zoom,
                    Size     = new Size(80, 120),
                    Margin   = new Padding(5)
                };
                panelComputer.Controls.Add(backPic);
            }

            lblScore.Text = $"分數: {player.GetScore()}";
            lblWins.Text  = $"勝場: {playerName} {playerWins} - 電腦 {computerWins}";
        }

        private void BtnHit_Click(object sender, EventArgs e)
        {
            if (deck.CardsRemaining > 0)
                player.AddCard(deck.DrawCard());

            if (computer.GetScore() < 17 && deck.CardsRemaining > 0)
                computer.AddCard(deck.DrawCard());

            RefreshUI();

            int ps = player.GetScore(), cs = computer.GetScore();
            string result = null;
            if (ps > 21 && cs > 21)
                result = $"平局! ({ps} vs {cs})";
            else if (ps > 21)
            {
                computerWins++;
                result = $"玩家爆牌! ({ps} vs {cs})";
            }
            else if (cs > 21)
            {
                playerWins++;
                result = $"電腦爆牌! ({ps} vs {cs})";
            }

            if (result != null)
            {
                UpdateWins();
                EndRound(result);
            }
        }

        private void BtnStand_Click(object sender, EventArgs e)
        {
            while (computer.GetScore() < 17 && deck.CardsRemaining > 0)
                computer.AddCard(deck.DrawCard());

            RefreshUI();

            int ps = player.GetScore(), cs = computer.GetScore();
            string result;
            if ((ps > 21 && cs > 21) || ps == cs)
                result = $"平局! ({ps} vs {cs})";
            else if (ps > 21 || (cs <= 21 && cs > ps))
            {
                computerWins++;
                result = $"電腦獲勝! ({ps} vs {cs})";
            }
            else
            {
                playerWins++;
                result = $"玩家獲勝! ({ps} vs {cs})";
            }

            UpdateWins();
            EndRound(result);
        }

        private void EndRound(string result)
        {
            roundRecords.Add(result);
            SaveRecords();
            RevealComputer();
            MessageBox.Show(result, "Round Over");
            StartNewRound();
        }

        private void RevealComputer()
        {
            panelComputer.Controls.Clear();
            foreach (var c in computer.Hand)
            {
                var pb = new PictureBox()
                {
                    Image    = Image.FromFile(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", c.GetImageFileName())),
                    SizeMode = PictureBoxSizeMode.Zoom,
                    Size     = new Size(80, 120),
                    Margin   = new Padding(5)
                };
                panelComputer.Controls.Add(pb);
            }
        }

        private void UpdateWins() => lblWins.Text = $"勝場: {playerName} {playerWins} - 電腦 {computerWins}";

        private void GameOver()
        {
            MessageBox.Show("牌堆不足，遊戲結束", "Game Over");
            btnHit.Enabled = btnStand.Enabled = false;
        }

        private void SaveRecords()
        {
            var folder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Records");
            Directory.CreateDirectory(folder);
            var file = Path.Combine(folder, $"{playerName}_records.txt");
            File.WriteAllLines(file, roundRecords);
        }
    }
}
