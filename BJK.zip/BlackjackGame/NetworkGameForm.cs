using System;
using System.Drawing;
using System.IO;
using System.IO.Pipes;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections.Generic;

namespace Blackjack21Game
{
    public class NetworkGameForm : Form
    {
        private string playerName;
        private bool isHost;
        private PipeStream pipeStream;

        public NetworkGameForm(string name, bool host, PipeStream stream)
        {
            playerName = name;
            isHost = host;
            pipeStream = stream;
            DoubleBuffered = true;
            InitializeComponent();
            BeginDeckExchange();
        }

        private Label lblInfo;
        private FlowLayoutPanel panelLocal, panelRemote;
        private Button btnHit, btnStand;

        private Deck deck;
        private Player localPlayer;
        private Player remotePlayer;
        private bool localStand, remoteStand;

        private void InitializeComponent()
        {
            Text = "NamedPipe Blackjack - " + playerName;
            ClientSize = new Size(900, 700);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(30, 30, 30);

            lblInfo = new Label() { Text = "準備發牌...", ForeColor = Color.White, Location = new Point(20, 20), AutoSize = true };

            panelRemote = new FlowLayoutPanel()
            {
                Location    = new Point(50, 60),
                Size        = new Size(800, 150),
                BackColor   = Color.FromArgb(50,50,50),
                BorderStyle = BorderStyle.FixedSingle,
                Padding     = new Padding(10)
            };
            panelLocal = new FlowLayoutPanel()
            {
                Location    = new Point(50, 500),
                Size        = new Size(800, 150),
                AutoScroll  = true,
                BackColor   = Color.FromArgb(50,50,50),
                BorderStyle = BorderStyle.FixedSingle,
                Padding     = new Padding(10)
            };

            btnHit = new Button() { Text = "加牌", Location = new Point(350, 300), Size = new Size(100, 50) };
            btnStand = new Button() { Text = "結算", Location = new Point(500, 300), Size = new Size(100, 50) };

            btnHit.Click += BtnHit_Click;
            btnStand.Click += BtnStand_Click;

            Controls.AddRange(new Control[] { lblInfo, panelRemote, panelLocal, btnHit, btnStand });

            btnHit.Enabled = btnStand.Enabled = false;
        }

        private void BeginDeckExchange()
        {
            if (isHost)
            {
                deck = new Deck();
                Task.Run(() =>
                {
                    try
                    {
                        var writer = new StreamWriter(pipeStream) { AutoFlush = true };
                        var files = deck.GetCardFileNames();
                        writer.WriteLine(string.Join(",", files));
                        Invoke(new Action(DealInitialCards));
                    }
                    catch { }
                });
            }
            else
            {
                Task.Run(() =>
                {
                    try
                    {
                        var reader = new StreamReader(pipeStream);
                        var line = reader.ReadLine();
                        var arr = line.Split(',');
                        deck = new Deck(arr);
                        Invoke(new Action(DealInitialCards));
                    }
                    catch { }
                });
            }
        }

        private void DealInitialCards()
        {
            localPlayer = new Player();
            remotePlayer = new Player();
            localStand = remoteStand = false;

            var c1 = deck.DrawCard();
            localPlayer.AddCard(c1);
            SendCard(c1);

            var c2 = deck.DrawCard();
            remotePlayer.AddCard(c2);

            RefreshUI();
            btnHit.Enabled = btnStand.Enabled = true;
            StartListening();
        }

        private void StartListening()
        {
            Task.Run(() => 
            {
                try
                {
                    var reader = new StreamReader(pipeStream);
                    while (true)
                    {
                        string line;
                        try { line = reader.ReadLine(); if (line == null) break; }
                        catch { break; }

                        if (line.StartsWith("CARD,"))
                        {
                            var fname = line.Substring(5);
                            var card = Card.FromFileName(fname);
                            remotePlayer.AddCard(card);
                            Invoke(new Action(RefreshUI));
                        }
                        else if (line == "STAND")
                        {
                            remoteStand = true;
                            Invoke(new Action(CheckBothStand));
                        }
                    }
                }
                catch { }
            });
        }

        private void SendCard(Card c)
        {
            if (pipeStream == null || !pipeStream.IsConnected) return;
            try
            {
                var writer = new StreamWriter(pipeStream) { AutoFlush = true };
                writer.WriteLine("CARD," + c.GetImageFileName());
            }
            catch { }
        }

        private void BtnHit_Click(object sender, EventArgs e)
        {
            if (deck.CardsRemaining > 0)
            {
                var c = deck.DrawCard();
                localPlayer.AddCard(c);
                SendCard(c);
                RefreshUI();
                if (localPlayer.GetScore() > 21)
                {
                    MessageBox.Show("爆牌! 結束回合", "Round Over");
                    EndGame();
                }
            }
        }

        private void BtnStand_Click(object sender, EventArgs e)
        {
            localStand = true;
            try
            {
                var writer = new StreamWriter(pipeStream) { AutoFlush = true };
                writer.WriteLine("STAND");
            }
            catch { }
            btnHit.Enabled = btnStand.Enabled = false;
            CheckBothStand();
        }

        private void CheckBothStand()
        {
            if (localStand && remoteStand)
            {
                int ls = localPlayer.GetScore(), rs = remotePlayer.GetScore();
                string result;
                if ((ls > 21 && rs > 21) || ls == rs)
                    result = "平局";
                else if (ls > 21 || (rs <= 21 && rs > ls))
                    result = "遠端玩家獲勝";
                else
                    result = "本地玩家獲勝";
                MessageBox.Show(result, "Game Over");
                EndGame();
            }
        }

        private void RefreshUI()
        {
            panelLocal.Controls.Clear();
            foreach (var c in localPlayer.Hand)
            {
                var pb = new PictureBox()
                {
                    Image    = Image.FromFile(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", c.GetImageFileName())),
                    SizeMode = PictureBoxSizeMode.Zoom,
                    Size     = new Size(80, 120),
                    Margin   = new Padding(5)
                };
                panelLocal.Controls.Add(pb);
            }
            panelRemote.Controls.Clear();
            foreach (var c in remotePlayer.Hand)
            {
                var pb = new PictureBox()
                {
                    Image    = Image.FromFile(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", c.GetImageFileName())),
                    SizeMode = PictureBoxSizeMode.Zoom,
                    Size     = new Size(80, 120),
                    Margin   = new Padding(5)
                };
                panelRemote.Controls.Add(pb);
            }
            lblInfo.Text = $"本地: {localPlayer.GetScore()}  遠端: {remotePlayer.GetScore()}";
        }

        private void EndGame()
        {
            try { pipeStream?.Close(); } catch { }
            btnHit.Enabled = btnStand.Enabled = false;
        }
    }
}
