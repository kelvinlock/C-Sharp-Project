namespace Blackjack21Game
{
    public class Card
    {
        public string Suit { get; set; }
        public string Rank { get; set; }

        public int GetValue()
        {
            if (int.TryParse(Rank, out int v)) return v;
            if (Rank == "A") return 11;
            return 10;
        }

        public string GetImageFileName()
        {
            string s = Suit switch
            {
                "Hearts" => "H",
                "Diamonds" => "D",
                "Clubs" => "C",
                "Spades" => "S",
                _ => ""
            };
            return $"{Rank}{s}.png";
        }

        public static Card FromFileName(string fileName)
        {
            var name = fileName.Replace(".png", "");
            char suitChar = name[name.Length - 1];
            string suit = suitChar switch
            {
                'H' => "Hearts",
                'D' => "Diamonds",
                'C' => "Clubs",
                'S' => "Spades",
                _ => "Clubs"
            };
            var rank = name.Substring(0, name.Length - 1);
            return new Card { Suit = suit, Rank = rank };
        }
    }
}
