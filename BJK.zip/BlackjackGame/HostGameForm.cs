using System;
using System.Drawing;
using System.IO.Pipes;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Blackjack21Game
{
    public class HostGameForm : Form
    {
        private string playerName;
        private NamedPipeServerStream pipeServer;
        private CancellationTokenSource cts;

        private Label lblStatus;
        private Button btnStartGame, btnClose;

        public HostGameForm(string name)
        {
            playerName = name;
            InitializeComponent();
            StartListeningAsync();
        }

        private void InitializeComponent()
        {
            Text = "主機 - " + playerName;
            ClientSize = new Size(400, 150);
            StartPosition = FormStartPosition.CenterScreen;

            lblStatus = new Label() { Text = "等待玩家加入...", Location = new Point(20, 20), AutoSize = true };
            btnStartGame = new Button() { Text = "開始遊戲", Location = new Point(20, 60), Size = new Size(120, 40), Enabled = false };
            btnClose = new Button() { Text = "關閉", Location = new Point(160, 60), Size = new Size(120, 40) };

            btnStartGame.Click += BtnStartGame_Click;
            btnClose.Click += (s, e) => { StopListening(); Close(); };

            Controls.AddRange(new Control[] { lblStatus, btnStartGame, btnClose });
        }

        private async void StartListeningAsync()
        {
            pipeServer = new NamedPipeServerStream(
                "BlackjackPipe",
                PipeDirection.InOut,
                1,
                PipeTransmissionMode.Message,
                PipeOptions.Asynchronous);

            cts = new CancellationTokenSource();

            try
            {
                await pipeServer.WaitForConnectionAsync(cts.Token);
                if (!IsDisposed)
                {
                    lblStatus.Invoke(new Action(() =>
                    {
                        lblStatus.Text = "玩家已加入";
                        btnStartGame.Enabled = true;
                    }));
                }
            }
            catch { }
        }

        private void BtnStartGame_Click(object sender, EventArgs e)
        {
            if (pipeServer == null || !pipeServer.IsConnected)
            {
                MessageBox.Show("尚未連線成功，無法開始遊戲！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var game = new NetworkGameForm(playerName, true, pipeServer);
            game.ShowDialog();

            StopListening();
            Close();
        }

        private void StopListening()
        {
            try
            {
                cts?.Cancel();
                pipeServer?.Dispose();
            }
            catch { }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            StopListening();
            base.OnFormClosing(e);
        }
    }
}
