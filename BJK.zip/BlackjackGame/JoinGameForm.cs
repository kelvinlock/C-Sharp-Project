using System;
using System.Drawing;
using System.IO.Pipes;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Blackjack21Game
{
    public class JoinGameForm : Form
    {
        private string playerName;
        private NamedPipeClientStream pipeClient;
        private CancellationTokenSource cts;

        private Label lblStatus;
        private Button btnConnect, btnCancel;

        public JoinGameForm(string name)
        {
            playerName = name;
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            Text = "加入遊戲 - " + playerName;
            ClientSize = new Size(400, 150);
            StartPosition = FormStartPosition.CenterScreen;

            lblStatus = new Label() { Text = "尚未連線", Location = new Point(20, 20), AutoSize = true };
            btnConnect = new Button() { Text = "連線主機", Location = new Point(20, 60), Size = new Size(120, 40) };
            btnCancel  = new Button() { Text = "取消", Location = new Point(160, 60), Size = new Size(120, 40) };

            btnConnect.Click += BtnConnect_Click;
            btnCancel.Click  += (s, e) => { cts?.Cancel(); pipeClient?.Dispose(); Close(); };

            Controls.AddRange(new Control[] { lblStatus, btnConnect, btnCancel });
        }

        private async void BtnConnect_Click(object sender, EventArgs e)
        {
            btnConnect.Enabled = false;
            lblStatus.Text = "嘗試連線...";
            cts = new CancellationTokenSource();

            pipeClient = new NamedPipeClientStream(
                ".", "BlackjackPipe", PipeDirection.InOut, PipeOptions.Asynchronous);

            try
            {
                await pipeClient.ConnectAsync(cts.Token);

                if (!pipeClient.IsConnected)
                {
                    lblStatus.Text = "連線失敗";
                    btnConnect.Enabled = true;
                    return;
                }

                lblStatus.Text = "已連線";

                var game = new NetworkGameForm(playerName, false, pipeClient);
                game.ShowDialog();

                Close();
            }
            catch { lblStatus.Text = "連線失敗"; btnConnect.Enabled = true; }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            try
            {
                cts?.Cancel();
                pipeClient?.Dispose();
            }
            catch { }
            base.OnFormClosing(e);
        }
    }
}
