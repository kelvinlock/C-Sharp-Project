using System;
using System.Drawing;
using System.Windows.Forms;

namespace Blackjack21Game
{
    public class LoginForm : Form
    {
        public string PlayerName { get; private set; }
        private TextBox txtName;
        private Button btnLogin;

        public LoginForm()
        {
            Text = "玩家登入";
            ClientSize = new Size(300, 150);
            StartPosition = FormStartPosition.CenterScreen;

            var lbl = new Label()
            {
                Text = "請輸入玩家名稱:",
                Location = new Point(10, 20),
                AutoSize = true
            };
            txtName = new TextBox() { Location = new Point(10, 50), Width = 260 };
            btnLogin = new Button()
            {
                Text = "登入",
                Location = new Point(100, 90),
                DialogResult = DialogResult.OK
            };
            btnLogin.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtName.Text))
                {
                    MessageBox.Show("名稱不可為空！", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.DialogResult = DialogResult.None;
                }
                else
                {
                    PlayerName = txtName.Text.Trim();
                }
            };

            Controls.AddRange(new Control[] { lbl, txtName, btnLogin });
        }
    }
}
