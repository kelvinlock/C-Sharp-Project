using System;
using System.Drawing;
using System.Windows.Forms;

namespace Blackjack21Game
{
    public class MainMenuForm : Form
    {
        private string playerName;
        private Button btnVsComputer, btnRecords;
        private Label lblWelcome;

        public MainMenuForm(string name)
        {
            playerName = name;
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            Text = "主選單";
            ClientSize = new Size(400, 200);
            StartPosition = FormStartPosition.CenterScreen;

            lblWelcome = new Label()
            {
                Text = $"歡迎, {playerName}!",
                Location = new Point(20, 20),
                AutoSize = true,
                Font = new Font(Font.FontFamily, 12, FontStyle.Bold)
            };

            btnVsComputer = new Button()
            {
                Text = "VS 電腦",
                Location = new Point(50, 80),
                Size = new Size(120, 40)
            };

            btnRecords = new Button()
            {
                Text = "對戰紀錄",
                Location = new Point(220, 80),
                Size = new Size(120, 40)
            };

            btnVsComputer.Click += (s, e) =>
            {
                Hide();
                var game = new GameForm(playerName);
                game.ShowDialog();
                Show();
            };

            btnRecords.Click += (s, e) =>
            {
                Hide();
                var rec = new RecordForm(playerName);
                rec.ShowDialog();
                Show();
            };

            Controls.AddRange(new Control[] { lblWelcome, btnVsComputer, btnRecords });
        }
    }
}
