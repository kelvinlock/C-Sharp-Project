using System;
using System.Windows.Forms;

namespace Blackjack21Game
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            using var login = new LoginForm();
            if (login.ShowDialog() != DialogResult.OK) return;
            Application.Run(new MainMenuForm(login.PlayerName));
        }
    }
}
