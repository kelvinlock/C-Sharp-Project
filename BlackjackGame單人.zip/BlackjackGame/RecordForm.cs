using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Blackjack21Game
{
    public class RecordForm : Form
    {
        public RecordForm(string playerName)
        {
            Text = "History";
            ClientSize = new Size(300, 400);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.Black;
            ForeColor = Color.White;

            var lb = new ListBox { Dock = DockStyle.Fill, BackColor = Color.Black, ForeColor = Color.White };
            var path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "history.txt");
            if (File.Exists(path))
                lb.Items.AddRange(File.ReadAllLines(path).Where(l => l.StartsWith(playerName + ":")).ToArray());
            Controls.Add(lb);
        }
    }
}
