namespace Blackjack21Game
{
    public class Card
    {
        public string Suit { get; set; }
        public string Rank { get; set; }
        public int GetValue()
        {
            if (int.TryParse(Rank, out var v)) return v;
            if (Rank == "A") return 11;
            return 10;
        }
        public string GetImageFileName()
        {
            string s = Suit switch { "Clubs"=>"C","Diamonds"=>"D","Hearts"=>"H","Spades"=>"S", _ => "" };
            return $"{Rank}{s}.png";
        }
    }
}
