using System;
using System.Drawing;
using System.Windows.Forms;

namespace Blackjack21Game
{
    public class LoginForm : Form
    {
        public string PlayerName { get; private set; }
        private TextBox txtName;
        private Button btnOk;

        public LoginForm()
        {
            Text = "Login";
            ClientSize = new Size(300, 150);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.Black;
            ForeColor = Color.White;

            var lbl = new Label
            {
                Text = "Enter your name:",
                Location = new Point(20, 20),
                AutoSize = true,
                ForeColor = Color.White
            };

            txtName = new TextBox
            {
                Location = new Point(20, 50),
                Size = new Size(240, 25),
                BackColor = Color.DarkGray,
                ForeColor = Color.White
            };

            btnOk = new Button
            {
                Text = "OK",
                Location = new Point(110, 90),
                Size = new Size(80, 30),
                BackColor = Color.DimGray,
                ForeColor = Color.White
            };
            btnOk.Click += BtnOk_Click;

            Controls.AddRange(new Control[] { lbl, txtName, btnOk });
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            var name = txtName.Text.Trim();
            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Please enter your name.", "Error");
                return;
            }
            PlayerName = name;
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
