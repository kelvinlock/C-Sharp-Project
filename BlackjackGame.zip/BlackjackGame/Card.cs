using System;

namespace Blackjack21Game
{
    public class Card
    {
        public string Suit { get; set; }
        public string Rank { get; set; }
        public int GetValue()
        {
            if (int.TryParse(Rank, out int v)) return v;
            if (Rank == "A") return 11;
            return 10;
        }
        public string GetImageFileName()
        {
            string s = Suit switch
            {
                "Hearts" => "H",
                "Diamonds" => "D",
                "Clubs" => "C",
                "Spades" => "S",
                _ => string.Empty
            };
            return $"{Rank}{s}.png";
        }
    }
}
