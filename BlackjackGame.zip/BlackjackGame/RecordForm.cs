using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Blackjack21Game
{
    public class RecordForm : Form
    {
        public RecordForm(string playerName)
        {
            Text = "對戰紀錄";
            ClientSize = new Size(400, 300);
            StartPosition = FormStartPosition.CenterScreen;

            var txt = new TextBox()
            {
                Multiline = true,
                ReadOnly = true,
                Dock = DockStyle.Fill,
                ScrollBars = ScrollBars.Vertical,
                Font = new Font(Font.FontFamily, 10)
            };
            Controls.Add(txt);

            var folder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Records");
            var file = Path.Combine(folder, $"{playerName}_records.txt");
            if (File.Exists(file))
                txt.Text = string.Join(Environment.NewLine, File.ReadAllLines(file));
            else
                txt.Text = "目前尚無紀錄。";
        }
    }
}
