using System;
using System.Collections.Generic;

namespace Blackjack21Game
{
    public class Deck
    {
        private Stack<Card> cards;
        private static Random rng = new Random();
        public Deck()
        {
            var list = new List<Card>();
            string[] suits = { "Clubs", "Diamonds", "Hearts", "Spades" };
            string[] ranks = { "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K" };
            foreach (var s in suits)
                foreach (var r in ranks)
                    list.Add(new Card { Suit = s, Rank = r });
            Shuffle(list);
            cards = new Stack<Card>(list);
        }
        private void Shuffle(List<Card> list)
        {
            int n = list.Count;
            while (n > 1)
            {
                int i = rng.Next(n--);
                (list[n], list[i]) = (list[i], list[n]);
            }
        }
        public Card DrawCard() => cards.Pop();
        public int CardsRemaining => cards.Count;
    }
}
